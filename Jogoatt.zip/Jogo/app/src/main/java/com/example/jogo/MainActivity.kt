package com.example.jogo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var jogo: Jogo
    private lateinit var btchute: Button
    private lateinit var Menor: EditText
    private lateinit var Maior: EditText
    private lateinit var Numero: EditText
    private lateinit var Status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialize o jogo antes de definir o texto dos EditText
        jogo = Jogo()
        jogo.iniciarJogo()

        this.btchute = findViewById(R.id.btchute)
        this.Menor = findViewById(R.id.Menor)
        this.Maior = findViewById(R.id.Maior)
        this.Numero = findViewById(R.id.Numero)
        this.Status = findViewById(R.id.Status)

        this.Maior.setText(jogo.getMaior())
        this.Menor.setText(jogo.getMenor())

        this.btchute.setOnClickListener{
            val chutetext = Numero.text.toString()
            val chute = chutetext.toInt()
            jogo.chute(chute)
            this.Status.text = jogo.getStatus()
            this.Maior.setText(jogo.getMaior())
            this.Menor.setText(jogo.getMenor())
        }
    }
}
