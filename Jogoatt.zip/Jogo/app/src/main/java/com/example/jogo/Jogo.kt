package com.example.jogo

import kotlin.random.Random

class Jogo {
    private var numeroMenor: Int = 0

    private var numeroMaior: Int = 0

    private var numeroEscolhido: Int = 0

    private var status: String =""

    fun iniciarJogo(){

        numeroMenor = Random.nextInt(100)

        numeroMaior = numeroMenor + 100

        numeroEscolhido = Random.nextInt(numeroMenor, numeroMaior)

        status ="Novo jogo, esolha um número"

    }

    fun chute(numero: Int){
        var numero:Int = numero
        if (numero > numeroEscolhido){
            numeroMaior = numero
            status = "Executando, o número q vc chutou é maior"}
        else if(numero< numeroEscolhido){
            numeroMenor = numero
            status = "Executando, o número q vc chutou é menor"}
        else if ((numero < numeroMenor) || (numero > numeroMaior)){
            status = "Executando, o número precisa estar entre o intervalo"
        }
        else {
            status = "Ganhou!"
        }
    }
    fun getMenor(): Int {
        return numeroMenor
    }
    fun getMaior(): Int{
        return numeroMaior
    }
    fun getStatus(): String{
        return status
    }

}